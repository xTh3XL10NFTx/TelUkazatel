package com.example.kontakti;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.appcompat.app.AppCompatActivity;
import java.sql.SQLException;

public abstract class BaseClass extends AppCompatActivity {
    protected void initDb() throws SQLException {
        SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(
                        getFilesDir().getPath()+"/kontakti.db", null);
        String createQ="CREATE TABLE if not exists KONTAKTI( " +
                "ID integer PRIMARY KEY AUTOINCREMENT, " +
                "Name text not null, " +
                "Tel text not null, " +
                "Email text not null, " +
                "Desc text not null, " +
                "unique(Tel, Name) " +
                "); ";
        db.execSQL(createQ);
        db.close();
    }

    protected void ExecSQL(String SQL, Object[] args, OnQuerySuccess success) throws SQLException{
        SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(
                         getFilesDir().getPath()+"/kontakti.db", null);
        db.execSQL(SQL, args);
        success.OnSuccess();
        db.close();
    }

    public void SelectSQL(String SQL, String[] args, OnSelectElement iterate) throws Exception
    {
        SQLiteDatabase db=SQLiteDatabase.openOrCreateDatabase(
                            getFilesDir().getPath()+"/kontakti.db",null);
        Cursor cursor=db.rawQuery(SQL, args);
        while (cursor.moveToNext()){
            String ID=cursor.getString(cursor.getColumnIndex("ID"));
            String Name=cursor.getString(cursor.getColumnIndex("Name"));
            String Tel=cursor.getString(cursor.getColumnIndex("Tel"));
            String Email=cursor.getString(cursor.getColumnIndex("Email"));
            String Desc=cursor.getString(cursor.getColumnIndex("Desc"));
            iterate.OnElementIterate(Name, Tel, Email, Desc, ID);
        }
        db.close();
    }

    protected interface OnQuerySuccess{
        public void OnSuccess();}

    protected interface OnSelectElement{
        public void OnElementIterate(String Name, String Tel, String Email, String Desc, String ID);}
}
